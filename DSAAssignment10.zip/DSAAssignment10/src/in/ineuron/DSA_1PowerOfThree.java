package in.ineuron;

public class DSA_1PowerOfThree {

	    public static boolean isPowerOfThree(int n) {
	        if(n<=0) return false;
	        while(n%3==0){
	            n/=3;
	        }
	        return n==1;
	    }
	    
	    public static void main(String[] args) {
			
	    	int num=27;
	    	boolean ans;
	    	ans= isPowerOfThree(num);
	    	System.out.println(ans);
		}
	}

